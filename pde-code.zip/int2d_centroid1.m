function [p,w] = int2d_centroid1()
% function [p,w] = int2d_centroid1()
%
% This is the simplest triangle integration method.
p = [1/3, 1/3];
w = 1/2;
